let perfilSelecionado=null;

const telas=document.querySelectorAll(".screen");

function showScreen(id){
  telas.forEach(t=>t.classList.remove("active"));
  const destino=document.getElementById(id);
  if(destino){
    destino.classList.add("active");
    window.scrollTo({top:0,behavior:"smooth"});
  }
}

function ativarAba(tabId){
  const tabButton=document.querySelector(`.tab[data-tab="${tabId}"]`);
  const conteudo=document.getElementById(tabId);
  if(!tabButton || !conteudo) return;

  const tela=tabButton.closest(".screen");
  tela.querySelectorAll(".tab").forEach(t=>t.classList.remove("active"));
  tela.querySelectorAll(".tab-content").forEach(c=>c.classList.remove("active"));

  tabButton.classList.add("active");
  conteudo.classList.add("active");
}

document.querySelectorAll(".profile-option").forEach(btn=>{
  btn.addEventListener("click",()=>{
    document.querySelectorAll(".profile-option").forEach(b=>b.classList.remove("active"));
    btn.classList.add("active");
    perfilSelecionado=btn.dataset.profile;
  });
});

document.getElementById("btnIrLogin").addEventListener("click",()=>{
  if(!perfilSelecionado){
    alert("Selecione uma opção: Professor, Aluno ou Voluntário.");
    return;
  }
  showScreen("login");
});

document.getElementById("btnLogin").addEventListener("click",()=>{
  if(perfilSelecionado==="professor") showScreen("professorHome");
  if(perfilSelecionado==="aluno") showScreen("alunoHome");
  if(perfilSelecionado==="voluntario") showScreen("voluntarioHome");
});

document.addEventListener("click",(e)=>{
  const botao=e.target.closest("[data-go]");
  if(botao){
    const destino=botao.dataset.go;
    showScreen(destino);
    if(botao.dataset.tab){
      setTimeout(()=>ativarAba(botao.dataset.tab),50);
    }
  }
});

document.querySelectorAll(".tab").forEach(tab=>{
  tab.addEventListener("click",()=>ativarAba(tab.dataset.tab));
});

document.querySelectorAll(".quick,.course-card,.task-card,.student,.session,.project,.taskitem").forEach(el=>{
  el.addEventListener("mouseenter",()=>el.style.transform="translateY(-2px)");
  el.addEventListener("mouseleave",()=>el.style.transform="translateY(0)");
});

/* =========================
   MENU DAS TRÊS BARRINHAS
========================= */
const menuOverlay = document.getElementById("menuOverlay");
const sideMenu = document.getElementById("sideMenu");
const closeMenu = document.getElementById("closeMenu");
const logoutBtn = document.getElementById("logoutBtn");
const menuOptions = document.getElementById("menuOptions");
const menuTitle = document.getElementById("menuTitle");
const menuSubtitle = document.getElementById("menuSubtitle");

const menus = {
  professor: {
    title: "Menu Professor",
    subtitle: "Gerencie suas turmas",
    items: [
      { icon: "fa-house", label: "Portal do Professor", desc: "Voltar para o painel inicial", screen: "professorHome" },
      { icon: "fa-users", label: "Minhas Turmas", desc: "Ver todas as turmas", screen: "turmasProfessor" },
      { icon: "fa-circle-check", label: "Presença", desc: "Gerenciar sessões de presença", screen: "presencaProfessor" }
    ]
  },
  aluno: {
    title: "Menu Aluno",
    subtitle: "Acesse seus estudos",
    items: [
      { icon: "fa-book-open", label: "Meus Cursos", desc: "Ver cursos disponíveis", screen: "alunoHome" },
      { icon: "fa-clipboard-list", label: "Atividades", desc: "Pendentes e entregues", screen: "classAluno", tab: "alunoAtividades" },
      { icon: "fa-circle-check", label: "Presença", desc: "Registrar presença", screen: "classAluno", tab: "alunoPresenca" }
    ]
  },
  voluntario: {
    title: "Menu Voluntário",
    subtitle: "Acompanhe seus projetos",
    items: [
      { icon: "fa-house", label: "Início", desc: "Painel institucional", screen: "voluntarioHome" },
      { icon: "fa-diagram-project", label: "Projetos", desc: "Portfólio e rastreador", screen: "voluntarioHome", anchor: ".tracker" },
      { icon: "fa-square-check", label: "Tarefas", desc: "Tarefas semanais", screen: "voluntarioHome", anchor: ".tasks-box" }
    ]
  }
};

function openMenu(role){
  const menu = menus[role] || menus.professor;
  menuTitle.textContent = menu.title;
  menuSubtitle.textContent = menu.subtitle;
  menuOptions.innerHTML = "";

  menu.items.forEach(item => {
    const btn = document.createElement("button");
    btn.className = "menu-item";
    btn.innerHTML = `<i class="fa-solid ${item.icon}"></i><span><b>${item.label}</b><small>${item.desc}</small></span>`;
    btn.addEventListener("click", () => {
      closeSideMenu();
      showScreen(item.screen);
      if(item.tab){
        setTimeout(() => ativarAba(item.tab), 60);
      }
      if(item.anchor){
        setTimeout(() => {
          const telaAtual = document.querySelector(".screen.active");
          const alvo = telaAtual ? telaAtual.querySelector(item.anchor) : null;
          if(alvo) alvo.scrollIntoView({ behavior: "smooth", block: "start" });
        }, 120);
      }
    });
    menuOptions.appendChild(btn);
  });

  sideMenu.classList.add("active");
  menuOverlay.classList.add("active");
}

function closeSideMenu(){
  sideMenu.classList.remove("active");
  menuOverlay.classList.remove("active");
}

document.querySelectorAll(".menu-open").forEach(btn => {
  btn.addEventListener("click", (event) => {
    event.preventDefault();
    event.stopPropagation();
    openMenu(btn.dataset.role);
  });
});

closeMenu.addEventListener("click", closeSideMenu);
menuOverlay.addEventListener("click", closeSideMenu);

logoutBtn.addEventListener("click", () => {
  closeSideMenu();
  perfilSelecionado = null;
  document.querySelectorAll(".profile-option").forEach(btn => btn.classList.remove("active"));
  document.querySelectorAll(".search input").forEach(input => input.value = "");
  clearSearchFilters();
  showScreen("perfil");
});

/* =========================
   BUSCA BÁSICA
========================= */
function clearSearchFilters(){
  document.querySelectorAll(".is-hidden-by-search").forEach(el => el.classList.remove("is-hidden-by-search"));
  document.querySelectorAll(".search-empty").forEach(el => el.remove());
}

function getSearchableItems(screen){
  return Array.from(screen.querySelectorAll(
    ".course-card, .quick, .metric, .student, .task-card, .session, .project, .white-card, .deadline, .alert-card, .tasks-box, .notice"
  )).filter(item => !item.closest(".side-menu"));
}

function searchOnScreen(input){
  const screen = input.closest(".screen");
  if(!screen) return;

  const term = input.value.trim().toLowerCase();
  const items = getSearchableItems(screen);
  let visible = 0;

  screen.querySelectorAll(".search-empty").forEach(el => el.remove());

  if(!term){
    items.forEach(item => item.classList.remove("is-hidden-by-search"));
    return;
  }

  items.forEach(item => {
    const text = item.innerText.toLowerCase();
    const match = text.includes(term);
    item.classList.toggle("is-hidden-by-search", !match);
    if(match) visible++;
  });

  if(visible === 0){
    const aviso = document.createElement("div");
    aviso.className = "search-empty active";
    aviso.textContent = `Nenhum resultado encontrado para: ${input.value}`;
    const topbar = screen.querySelector(".topbar");
    if(topbar) topbar.insertAdjacentElement("afterend", aviso);
  }
}

document.querySelectorAll(".search input").forEach(input => {
  input.addEventListener("input", () => searchOnScreen(input));
  input.addEventListener("keydown", (event) => {
    if(event.key === "Escape"){
      input.value = "";
      searchOnScreen(input);
    }
  });
});
